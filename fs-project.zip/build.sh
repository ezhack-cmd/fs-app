#!/usr/bin/env bash
# 의존성 설치
pip install -r requirements.txt

# 빌드 완료 메시지
echo "Build completed successfully!" 